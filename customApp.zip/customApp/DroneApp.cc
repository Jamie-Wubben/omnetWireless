//ICMP error msg https://erg.abdn.ac.uk/users/gorry/course/inet-pages/icmp-code.html


#include "../customApp/DroneApp.h"

#include "../customApp/GeneralMsg_m.h"
#include "inet/common/ModuleAccess.h"
#include "inet/common/TagBase_m.h"
#include "inet/common/TimeTag_m.h"
#include "inet/common/lifecycle/ModuleOperations.h"
#include "inet/common/packet/Packet.h"
#include "inet/networklayer/common/FragmentationTag_m.h"
#include "inet/networklayer/common/L3AddressResolver.h"
#include "inet/transportlayer/contract/udp/UdpControlInfo_m.h"

namespace inet {

Define_Module(DroneApp);

// START operations
void DroneApp::initialize(int stage)
{
    event = new cMessage("event");
    ApplicationBase::initialize(stage);

}
void DroneApp::setArdusimListener(int port){
    ardusimListingSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (ardusimListingSocket == INVALID_SOCKET){
        throw cRuntimeError("DroneApp: cannot create ardusimListingSocket");
    }

    sockaddr_in sinInterface;
    sinInterface.sin_family = AF_INET;
    sinInterface.sin_addr.s_addr = INADDR_ANY;
    sinInterface.sin_port = htons(port);
    if (bind(ardusimListingSocket, (sockaddr *)&sinInterface, sizeof(sockaddr_in)) == SOCKET_ERROR){
        throw cRuntimeError("DroneApp: ardusimSocket bind() failed");
    }
    listen(ardusimListingSocket, SOMAXCONN);
}

void DroneApp::setArdusimTalker(int port){
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0 ) {
        perror("socket creation failed");
        exit(EXIT_FAILURE);
    }
    memset(&servaddr, 0, sizeof(servaddr));
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(port);
    servaddr.sin_addr.s_addr = INADDR_ANY;
}
void DroneApp::handleStartOperation(LifecycleOperation *operation)
{
    internalSocket.setOutputGate(gate("socketOut"));
    internalSocket.setBroadcast(true);
    int index = getParentModule()->getIndex();
    setArdusimListener(5000 + index);
    setArdusimTalker(6000 +index);
    scheduleAt(simTime()+1.0, event);

    internalSocket.bind(Ipv4Address(10,0,0,index+1), 2000);
}

// RUNNING operations
void DroneApp::handleMessageWhenUp(cMessage *msg){
    //The selfmessage is a trigger to listen to the ardusimSocket
    if(msg->isSelfMessage()){
        int bytesReceived = listenToArduSim(10000);
        if(bytesReceived){
            // A message came from ardusim now send it to the other node(s)
            char* msg = getArduSimMessage(bytesReceived);
            Packet *packet = createPacket(msg);
            if(getParentModule()->getIndex() == 0){
                internalSocket.sendTo(packet,Ipv4Address("10.0.0.2"),2000);
            }else if(getParentModule()->getIndex() == 1){
                internalSocket.sendTo(packet,Ipv4Address("10.0.0.1"),2000);
            }
        }
        scheduleAt(simTime()+0.5, event);
    }else{
        //This message must be a message from ardusim send by another node
        //So now send it to ardusim
        Packet *packet = check_and_cast<Packet *>(msg);
        char* message = getMessage(packet);
        EV << "sending message: " << message << endl;
        sendto(sockfd, (const char *)message, strlen(message), MSG_CONFIRM, (const struct sockaddr *) &servaddr,  sizeof(servaddr));
    }
}

char* DroneApp::getMessage(Packet *packet){
    const auto& payload = packet->peekData<GeneralMsg>();
    const char* s1 = payload->getPayload();
    int ss1 = getSizeString(s1);
    char id = '0' + getParentModule()->getIndex();
    char s2[] = "{\"receiverID\":x,";
    s2[14] = id;
    int ss2 = getSizeString(s2);

    char* s3 = new char[ss1+ss2];
    memmove(s3,s2,ss2); //take the message remove the last }
    memmove(s3+ss2,s1+1,ss1); // append s2
    return s3;
}

int DroneApp::getSizeString(const char* s){
    //Sizeof didn't work so we do it like this
    int len = 0;
    while (s[len] != '\0'){
        len++;
    }
    return len;
}

char* DroneApp::getArduSimMessage(int numReceivedBytes){
    int lastIndexOfMsg;
    for(int i=numReceivedBytes;i>0;i--){
        if(recvBuffer[i] == '}'){
            lastIndexOfMsg = i;
            break;
        }
    }
    int numchar = lastIndexOfMsg + 1;
    char* msg = new char[numchar + 1];
    strncpy(msg,recvBuffer,numchar);
    msg[numchar] = '\0';
    return msg;
}
Packet* DroneApp::createPacket(char* message){
    Packet *packet = new Packet("msg");
    const auto& payload = makeShared<GeneralMsg>();
    payload->setChunkLength(B(1000));
    payload->setPayload(message);
    packet->insertAtBack(payload);

    return packet;
}
int DroneApp::listenToArduSim(long usec){
    fd_set readFDs, writeFDs, exceptFDs;
    FD_ZERO(&readFDs);
    FD_ZERO(&writeFDs);
    FD_ZERO(&exceptFDs);

    FD_SET(ardusimListingSocket, &readFDs);
    timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = usec;


    if (select(FD_SETSIZE, &readFDs, &writeFDs, &exceptFDs, &timeout) > 0) {
        // Something happened on one of the sockets defined by FD_SET() check which one
        if(FD_ISSET(ardusimListingSocket, &readFDs)){
            // something happend at the udpSocket
            struct sockaddr_in cliaddr;
            memset(&cliaddr, 0, sizeof(cliaddr));
            socklen_t len = sizeof(cliaddr);
            int nBytes = recvfrom(ardusimListingSocket, (char *)recvBuffer, SIZE_MSG_BUFFER,MSG_WAITALL, ( struct sockaddr *) &cliaddr, &len);
            if(nBytes >= SIZE_MSG_BUFFER){
                EV_WARN << "msg buffer is full, increase size!" << endl;
            }
            return nBytes;
        }
    }
    return 0;
}
void DroneApp::socketDataArrived(UdpSocket *socket, Packet *packet){
    EV_WARN << "data arrived here not normal" << endl;
}

//STOP operations
DroneApp::~DroneApp(){

}
void DroneApp::socketClosed(UdpSocket *socket){
    EV << "socket closed" << endl;
}
void DroneApp::finish()
{
    cancelAndDelete(event);
    ApplicationBase::finish();
}
void DroneApp::handleStopOperation(LifecycleOperation *operation)
{
    internalSocket.close();
    delayActiveOperationFinish(par("stopOperationTimeout"));
}

// ERROR Operations
void DroneApp::socketErrorArrived(UdpSocket *socket, Indication *indication){
    EV_WARN << "Ignoring UDP error report " << indication->getName() << endl;
    delete indication;
}
void DroneApp::handleCrashOperation(LifecycleOperation *operation)
{
    if (operation->getRootModule() != getContainingNode(this)) // closes socket when the application crashed only
        internalSocket.destroy(); // TODO  in real operating systems, program crash detected by OS and OS closes sockets of crashed programs.
    internalSocket.setCallback(nullptr);
}

} // namespace inet


