//
// Copyright (C) 2000 Institut fuer Telematik, Universitaet Karlsruhe
// Copyright (C) 2004,2011 OpenSim Ltd.
//
// SPDX-License-Identifier: LGPL-3.0-or-later
//


#ifndef __INET_DRONEAPP_H
#define __INET_DRONEAPP_H

#include <vector>

#include "inet/applications/base/ApplicationBase.h"
#include "inet/transportlayer/contract/udp/UdpSocket.h"
#include <omnetpp/platdep/sockets.h>
#include <omnetpp.h>

#define length(array) ((sizeof(array)) / (sizeof(array[0])))
namespace inet {

/**
 * UDP application. See NED for more info.
 */
class INET_API DroneApp : public ApplicationBase, public UdpSocket::ICallback
{
    private:
        cMessage *event;
        int SIZE_MSG_BUFFER = 1000;
        char recvBuffer[1000];
        Packet* createPacket(char* message);
    protected:
        UdpSocket internalSocket;
        SOCKET ardusimListingSocket;
        int sockfd;
        struct sockaddr_in servaddr;

        //START operations
        virtual int numInitStages() const override { return NUM_INIT_STAGES; }
        virtual void initialize(int stage) override;
        virtual void handleStartOperation(LifecycleOperation *operation) override;
        void setArdusimListener(int port);
        void setArdusimTalker(int port);

        //RUNNING operations
        virtual void handleMessageWhenUp(cMessage *msg) override;
        virtual void socketDataArrived(UdpSocket *socket, Packet *packet) override;
        char* getMessage(Packet *packet);
        int getSizeString(const char* s);
        virtual void refreshDisplay(){};
        int listenToArduSim(long usec);
        char* getArduSimMessage(int numReceivedBytes);

        //STOP operations
        virtual void finish() override;
        virtual void handleStopOperation(LifecycleOperation *operation) override;
        virtual void socketClosed(UdpSocket *socket) override;

        //ERROR operations
        virtual void handleCrashOperation(LifecycleOperation *operation) override;
        virtual void socketErrorArrived(UdpSocket *socket, Indication *indication) override;


    public:
        DroneApp() {}
        ~DroneApp();
        };

} // namespace inet

#endif

